﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Incipit.Bundt.ModellingEngine;

namespace RRValidation
{
    class Program
    {
        static void Main()
        {
            //create T.
            var tmoT = ModelManager.CreateTypeModel("T", VersionInfo.OneZeroZeroZero);

            var etyResidenceType = tmoT.AddNewEnumeratedType(null, tmoT.NewMultilingualString("ResidenceType"));
            etyResidenceType.AddNewEnumeratedItem(null, tmoT.NewMultilingualString("Main"));
            var eitSecondary = etyResidenceType.AddNewEnumeratedItem(null, tmoT.NewMultilingualString("Secondary"));
            etyResidenceType.AddNewEnumeratedItem(eitSecondary, tmoT.NewMultilingualString("OnlyHolidays"));

            var clPerson = tmoT.AddNewClass(tmoT.NewMultilingualString("Person"), false);
            clPerson.AddNewAttribute(tmoT.NewMultilingualString("Name"), Cardinality.One, BaseDataType.Text);
            var clHouse = tmoT.AddNewClass(tmoT.NewMultilingualString("House"), false);
            clHouse.AddNewAttribute(tmoT.NewMultilingualString("Address"), Cardinality.One, BaseDataType.Text);
            clHouse.AddNewAttribute(tmoT.NewMultilingualString("ResidenceType"), Cardinality.One, etyResidenceType);
            ModelManager.Seal(tmoT);

            //create T'.
            var tmoTp = ModelManager.CreateTypeModel("Tp", VersionInfo.OneZeroZeroZero);

            var etyResidenceTypeX = tmoTp.AddNewEnumeratedType(null, tmoTp.NewMultilingualString("ResidenceType"));
            etyResidenceTypeX.AddNewEnumeratedItem(null, tmoTp.NewMultilingualString("Main"));
            var eitSecondaryX = etyResidenceTypeX.AddNewEnumeratedItem(null, tmoTp.NewMultilingualString("Secondary"));
            etyResidenceTypeX.AddNewEnumeratedItem(eitSecondaryX, tmoTp.NewMultilingualString("OnlyHolidays"));
            var eitForRentX = etyResidenceTypeX.AddNewEnumeratedItem(eitSecondaryX, tmoTp.NewMultilingualString("ForRent"));

            var clPersonX = tmoTp.AddNewClass(tmoTp.NewMultilingualString("Person"), false);
            var clHouseX = tmoTp.AddNewClass(tmoTp.NewMultilingualString("House"), false);
            var attAddressX = clHouseX.AddNewAttribute(tmoTp.NewMultilingualString("Address"), Cardinality.One, BaseDataType.Text);
            var attResidenceTypeX = clHouseX.AddNewAttribute(tmoTp.NewMultilingualString("ResidenceType"), Cardinality.One, etyResidenceTypeX);
            ModelManager.Seal(tmoTp);

            //create I'.
            var imoIp = ModelManager.CreateInstanceModel(tmoTp, "Ip", VersionInfo.OneZeroZeroZero);
            var oJane = imoIp.AddNewObject(clPersonX, "jane");
            var oFlat = imoIp.AddNewObject(clHouseX, "flat");
            oFlat.ValueSets[attAddressX].SetContents("21 Walker Street");
            oFlat.ValueSets[attResidenceTypeX].SetContents(eitForRentX);

            var imoI_O5 = ApplyRuleO5(tmoT, tmoTp, imoIp, "O5");
            var imoI_V1 = ApplyRuleV1(tmoT, tmoTp, imoIp, "V1");

            DisplayInstanceModel(imoIp);
            DisplayInstanceModel(imoI_O5);
            DisplayInstanceModel(imoI_V1);

            Console.ReadLine();
        }

        private static InstanceModel ApplyRuleV1(TypeModel tmoT, TypeModel tmoTp, InstanceModel imoIp, string strTag)
        {
            //create reinterpreted model I.
            var imoI = ModelManager.CreateInstanceModel(tmoT, "I_" + strTag, VersionInfo.OneZeroZeroZero);

            //iterate all objects in I'.
            foreach (var op in imoIp.Objects)
            {
                //find base class in T.
                var clT = tmoT.FindClass(op.Type.Name);

                //create reinterpreted object in I, including all its values.
                var oi = imoI.AddNewObject(clT, op.Identifier);
                foreach (var vsp in op.ValueSets)
                {
                    foreach (var vp in vsp.Values)
                    {
                        if (vsp.Type.Type is SimpleDataType)
                        {
                            oi.ValueSets[clT.FindAttribute(vsp.Type.Name)].SetContents(vp.Content);
                        }
                        else
                        {
                            var eitp = (EnumeratedItem)vp.Content;
                            var eit = tmoT.FindEnumeratedType(eitp.Owner.Name).FindEnumeratedItemByAbsoluteName(eitp.AbsoluteName);
                            oi.ValueSets[clT.FindAttribute(vsp.Type.Name)].SetContents(eit);
                        }

                        //if value corresponds to a reused enumerated type...
                        var ety = tmoT.FindEnumeratedType(vsp.Type.Type.Name);
                        if (vsp.Type.Type is EnumeratedType && ety != null)
                        {
                            //...and the enumerated item is extended and non-root...
                            var eitp = (EnumeratedItem)vp.Content;
                            if (eitp.SuperItem != null && ety.FindEnumeratedItemByAbsoluteName(eitp.AbsoluteName) == null)
                            {
                                var eitpAncestor = eitp.SuperItem;
                                while(eitpAncestor != null && ety.FindEnumeratedItemByAbsoluteName(eitpAncestor.AbsoluteName) == null)
                                {
                                    eitpAncestor = eitpAncestor.SuperItem;
                                }

                                var eitAncestor = ety.FindEnumeratedItemByAbsoluteName(eitpAncestor.AbsoluteName);
                                oi.ValueSets[clT.FindAttribute(vsp.Type.Name)].SetContents(eitAncestor);
                            }
                        }
                    }
                }
            }

            return imoI;
        }

        private static InstanceModel ApplyRuleO5(TypeModel tmoT, TypeModel tmoTp, InstanceModel imoIp, string strTag)
        {
            //create reinterpreted model I.
            var imoI = ModelManager.CreateInstanceModel(tmoT, "I_" + strTag, VersionInfo.OneZeroZeroZero);

            //iterate all objects in I'.
            foreach (var op in imoIp.Objects)
            {
                //find base class in T.
                var clT = tmoT.FindClass(op.Type.Name);

                //create reinterpreted object in I, including all its values.
                var oi = imoI.AddNewObject(clT, op.Identifier);
                foreach (var vsp in op.ValueSets)
                {
                    foreach (var vp in vsp.Values)
                    {
                        if (vsp.Type.Type is SimpleDataType)
                        {
                            oi.ValueSets[clT.FindAttribute(vsp.Type.Name)].SetContents(vp.Content);
                        }
                        else
                        {
                            var eitp = (EnumeratedItem)vp.Content;
                            var eit = tmoT.FindEnumeratedType(eitp.Owner.Name).FindEnumeratedItemByAbsoluteName(eitp.AbsoluteName);
                            oi.ValueSets[clT.FindAttribute(vsp.Type.Name)].SetContents(eit);
                        }
                    }
                }

                //if the object's type is extended...
                if (tmoT.Classes.Any(cl => cl.Name == op.Type.Name))
                {
                    //...and if the base class has an attribute that has been deleted in the extended model...
                    var attDeleted = clT.AllAttributes.FirstOrDefault(att => op.Type.FindAttribute(att.Name) == null);
                    if (attDeleted != null)
                    {
                        //...set it to unknown or null, depending on cardinality.
                        if (attDeleted.Cardinality.Minimum > 0)
                        {
                            oi.ValueSets[attDeleted].Values[0].SetToUnknown();
                        }
                    }
                }
            }

            return imoI;
        }

        private static void DisplayInstanceModel(InstanceModel imo)
        {
            Console.WriteLine();
            Console.WriteLine("Name: " + imo.Name);
            Console.WriteLine(imo.Objects.Count.ToString() + " objects.");
            foreach (var o in imo.Objects)
            {
                Console.WriteLine("Object " + o.Identifier);
                foreach (var vs in o.ValueSets)
                {
                    Console.WriteLine("  " + vs.Type.AsText);
                    Console.WriteLine("  Values");
                    foreach (var v in vs.Values)
                    {
                        Console.WriteLine("    " + v.AsText);
                    }
                }
            }
        }
    }
}
